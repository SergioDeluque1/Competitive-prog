#include <iostream>
#include <cmath>
#include <vector>
#include <random>
#include <ctime>
#include <algorithm>
#include <iomanip>
#include <set>

using namespace std;

class SudokuGenerator {
private:
    int n;  // Size of the Sudoku (n x n grid)
    int subgridSize; // Size of the subgrids (e.g., for 9x9 grid, subgridSize = 3)
    vector<vector<int>> grid; // Sudoku grid
    random_device rd;
    mt19937 gen;

public:
    SudokuGenerator(int size) : n(size), subgridSize(sqrt(size)), gen(rd()) {
        grid.resize(n, vector<int>(n, 0)); // Initialize the grid with zeros
    }

    // Helper function to print the grid with double dash for empty cells
    void printGrid() {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                if (grid[i][j] == 0) {
                    cout << "-- ";  // Empty cell
                } else {
                    cout << setw(2) << setfill('0') << grid[i][j] << " ";
                }
            }
            cout << endl;
        }
    }

    // Function to check if a number can be placed at position (row, col)
    bool isValidPlacement(int row, int col, int num) {
        // Check the row and column for duplicates
        for (int i = 0; i < n; ++i) {
            if (grid[row][i] == num || grid[i][col] == num) {
                return false;
            }
        }

        // Check the subgrid for duplicates
        int startRow = (row / subgridSize) * subgridSize;
        int startCol = (col / subgridSize) * subgridSize;
        for (int i = startRow; i < startRow + subgridSize; ++i) {
            for (int j = startCol; j < startCol + subgridSize; ++j) {
                if (grid[i][j] == num) {
                    return false;
                }
            }
        }

        return true;
    }

    // Function to fill the diagonal subgrids with random values
    void fillDiagonalSubgrids() {
        for (int subgridIndex = 0; subgridIndex < n; subgridIndex += subgridSize) {
            set<int> usedNumbers;
            // Randomly fill the 3x3 diagonal subgrid
            for (int i = subgridIndex; i < subgridIndex + subgridSize; ++i) {
                for (int j = subgridIndex; j < subgridIndex + subgridSize; ++j) {
                    // Create a random number that is not used in the subgrid
                    vector<int> availableNums;
                    for (int num = 1; num <= n; ++num) {
                        if (usedNumbers.find(num) == usedNumbers.end()) {
                            availableNums.push_back(num);
                        }
                    }

                    // Randomly select a number from available options
                    uniform_int_distribution<> dis(0, availableNums.size() - 1);
                    int selectedNum = availableNums[dis(gen)];
                    grid[i][j] = selectedNum;
                    usedNumbers.insert(selectedNum);
                }
            }
        }
    }

    // Function to swap 50% of the cells in the grid randomly
    void swapCells(int swapPercentage) {
        vector<pair<int, int>> filledCells;
        
        // Collect all the filled cells in the grid
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                if (grid[i][j] != 0) {
                    filledCells.push_back({i, j});
                }
            }
        }

        // Shuffle the list of filled cells to randomize the order
        uniform_int_distribution<> dis(0, filledCells.size() - 1);
        
        // Replacing random_shuffle with std::shuffle and using the random engine
        shuffle(filledCells.begin(), filledCells.end(), gen);  // Shuffle using std::shuffle

        // Determine how many cells to swap based on the percentage
        int numCellsToSwap = filledCells.size() * swapPercentage / 100;

        for (int swapCount = 0; swapCount < numCellsToSwap; ++swapCount) {
            // Randomly select a cell to swap from the shuffled filled cells
            int idx1 = swapCount; // Since the list is shuffled, we take the first numCellsToSwap elements
            int row1 = filledCells[idx1].first;
            int col1 = filledCells[idx1].second;

            // Find a valid empty cell to swap with
            vector<pair<int, int>> emptyCells;
            for (int i = 0; i < n; ++i) {
                for (int j = 0; j < n; ++j) {
                    if (grid[i][j] == 0) {
                        emptyCells.push_back({i, j});
                    }
                }
            }

            if (emptyCells.empty()) return; // If no empty cells, exit

            // Randomly select an empty cell
            int idx2 = dis(gen) % emptyCells.size();  // Randomly pick an empty cell
            int row2 = emptyCells[idx2].first;
            int col2 = emptyCells[idx2].second;

            // Swap the cells
            swap(grid[row1][col1], grid[row2][col2]);
        }
    }

    // Method to remove some cells to create the puzzle (33% removal)
    void removeCells(int numberOfRemovals) {
        uniform_int_distribution<> dis(0, n - 1);

        int removed = 0;
        while (removed < numberOfRemovals) {
            int row = dis(gen);
            int col = dis(gen);
            if (grid[row][col] != 0) {
                grid[row][col] = 0;
                removed++;
            }
        }
    }

    // Function to generate the Sudoku puzzle
    void generate(int swapPercentage = 50) {
        // First, fill the diagonal subgrids randomly
        fillDiagonalSubgrids();

        cout << "Generated Completed Sudoku Grid (Diagonal Filled): \n";
        printGrid();

        // Now, swap cells to randomize the puzzle
        swapCells(swapPercentage);

        cout << "\nPuzzle after swapping (" << swapPercentage << "%): \n";
        printGrid();
    }
};

int main() {
    int k;
    cout << "Enter a number (e.g., 3 for a 9x9 grid, 4 for a 16x16 grid): ";
    cin >> k;

    int n = k * k;

    try {
        SudokuGenerator generator(n);
        generator.generate(50);  // Swap 50% of the cells
    } catch (const invalid_argument& e) {
        cout << e.what() << endl;
    }

    return 0;
}
